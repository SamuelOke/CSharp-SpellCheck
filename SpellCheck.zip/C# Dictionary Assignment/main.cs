// Spell Check Starter
// This start code creates two lists
// 1: dictionary: an array containing all of the words from "dictionary.txt"
// 2: aliceWords: an array containing all of the words from "AliceInWonderland.txt"

using System;
using System.Diagnostics;
using System.Text.RegularExpressions;

class Program {
    static int linearSearchString(string[] anArray, string item)
    {

        for (int i = 0; i < anArray.Length; i++)
        {
            if (anArray[i] == item)
            {
                return i;
            }
        }

        return -1;
    }
 
    static int binarySearchString(string[] anArray, string item)
    {
        int lower = 0;
        int upper = anArray.Length - 1;

        while (lower <= upper)
        {
            int mid = (upper + lower) / 2;
            int itemCheck = string.Compare(item, anArray[mid]);
            if (item == anArray[mid])
            {
                return mid;
            }
            else if (itemCheck == -1)
            {
                upper = mid - 1;
            }
            else
            {
                lower = mid + 1;
            }
        }

        return -1;
    }
    public static void Main(string[] args)
    {

        // Load data files into arrays
        String[] dictionary = System.IO.File.ReadAllLines(@"F:/CS 30/C# Dictionary Assignment/data-files/dictionary.txt");
        String aliceText = System.IO.File.ReadAllText(@"F:/CS 30/C# Dictionary Assignment/data-files/AliceInWonderLand.txt");
        String[] aliceWords = Regex.Split(aliceText, @"\s+");
        bool endFunction = false;

        // Print first 50 values of each list to verify contents
        Console.WriteLine("***DICTIONARY***");
        printStringArray(dictionary, 0, 50);

        Console.WriteLine("***ALICE WORDS***");
        printStringArray(aliceWords, 0, 50);

        Console.WriteLine("This is a list of 50 words from each txt file. Press any key to continue to the menu...");
        Console.ReadKey();
        do
        {
            Console.Clear();
            Console.WriteLine("Main Menu");
            Console.WriteLine("Type the number corresponding to the option you want ");
            Console.WriteLine("1. Spell Check a Word (Linear Search)");
            Console.WriteLine("2. Spell Check a Word (Binary Search)");
            Console.WriteLine("3. Spell Check Alice in Wonderland (Linear Search)");
            Console.WriteLine("4. Spell Check Alice in Wonderland (Binary Search)");
            Console.WriteLine("5. Exit");
            Console.WriteLine("Enter Option Here: ");
            int userInput = Convert.ToInt32(Console.ReadLine());
            if (userInput == 1)
            {
                var watch = Stopwatch.StartNew();
                Console.WriteLine("Please enter a word: ");
                string linearInput = Console.ReadLine();
                Console.WriteLine("Linear search starting...");
                int result = linearSearchString(dictionary, linearInput);
                watch.Stop();
                var elapsedMs = watch.ElapsedMilliseconds;
                if (result == -1)
                {
                    Console.WriteLine(linearInput + " is not in the list! It took " + elapsedMs + " milliseconds to execute!");
                    Console.WriteLine("Press any key to continue...");
                    Console.ReadKey();
                }
                else
                { 
                    Console.WriteLine(linearInput + " is in the position " + result + "! It took " + elapsedMs + " milliseconds to execute!");
                    Console.WriteLine("Press any key to continue...");
                    Console.ReadKey();
                }
            }
            else if (userInput == 2)
            {
                var watch = Stopwatch.StartNew();
                Console.WriteLine("Please enter a word: ");
                string binaryInput = Console.ReadLine();
                Console.WriteLine("Binary search starting...");
                int result = binarySearchString(dictionary, binaryInput);
                watch.Stop();
                var elapsedMs = watch.ElapsedMilliseconds;
                if (result == -1)
                {
                    Console.WriteLine(binaryInput + " is not in the list! It took " + elapsedMs + " milliseconds to execute!");
                    Console.WriteLine("Press any key to continue...");
                    Console.ReadKey();
                }
                else
                {
                    Console.WriteLine(binaryInput + " is in the position " + result + "! It took " + elapsedMs + " milliseconds to execute!");
                    Console.WriteLine("Press any key to continue...");
                    Console.ReadKey();
                }
            }
            else if (userInput == 3)
            {
                var watch = Stopwatch.StartNew();
                Console.WriteLine("Please enter a word: ");
                string linearInput = Console.ReadLine();
                Console.WriteLine("Linear search starting...");
                int result = linearSearchString(aliceWords, linearInput);
                watch.Stop();
                var elapsedMs = watch.ElapsedMilliseconds;
                if (result == -1)
                {
                    Console.WriteLine(linearInput + " is not in the list! It took " + elapsedMs + " milliseconds to execute!");
                    Console.WriteLine("Press any key to continue...");
                    Console.ReadKey();
                }
                else
                {
                    Console.WriteLine(linearInput + " is in the position " + result + "! It took " + elapsedMs + " milliseconds to execute!");
                    Console.WriteLine("Press any key to continue...");
                    Console.ReadKey();
                }
            }
            else if (userInput == 4)
            {
                var watch = Stopwatch.StartNew();
                Console.WriteLine("Please enter a word: ");
                string binaryInput = Console.ReadLine();
                Console.WriteLine("Binary search starting...");
                int result = binarySearchString(aliceWords, binaryInput);
                watch.Stop();
                var elapsedMs = watch.ElapsedMilliseconds;
                if (result == -1)
                {
                    Console.WriteLine(binaryInput + " is not in the list! It took " + elapsedMs + " milliseconds to execute!");
                    Console.WriteLine("Press any key to continue...");
                    Console.ReadKey();
                }
                else
                {
                    Console.WriteLine(binaryInput + " is in the position " + result + "! It took " + elapsedMs + " milliseconds to execute!");
                    Console.WriteLine("Press any key to continue...");
                    Console.ReadKey();
                }
            }
            else if (userInput == 5)
            {
                Console.WriteLine("Shutting down the program. Press any key to continue...");
                Console.ReadKey();
                endFunction = true;
            }
            else
            {
                Console.WriteLine("Syntax error! That isn't an option that you can make.");
                Console.WriteLine("Press any key to continue...");
                Console.ReadKey();
            }
        } 
        while (endFunction != true);

    }

        public static void printStringArray(String[] array, int start, int stop) {
    // Print out array elements at index values from start to stop 
    for (int i = start; i < stop; i++) {
      Console.WriteLine(array[i]);
    }
  }

  
}